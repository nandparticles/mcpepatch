# mcpepatch
patch mcpe

# takeownership
https://github.com/Abhinav1217/TakeOwnership


