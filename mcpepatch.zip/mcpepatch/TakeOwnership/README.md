## This is Registry Entries for Windows OS

This file add registry entry in windows OS adding capabilities to take ownership of any file or folder by simpling right-clicking on it and selecting it from context menu.

To install just execute InstallTakeOwnership.reg.
It will Add the registry entries.

To uninstall, execute RemoveTakeOwnership.reg.

_Credit goes to http://www.howtogeek.com/howto/windows-vista/add-take-ownership-to-explorer-right-click-menu-in-vista/. This is just a backup for me for future._